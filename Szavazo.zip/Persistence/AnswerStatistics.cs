﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Persistence
{
    public class AnswerStatistics
    {
        public string Text { get; set; }

        public double Percent { get; set; }
        public int NumberOfVotes { get; set; }
    }
}
