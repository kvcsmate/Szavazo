﻿namespace Szavazo.Persistence
{
    public enum DbType
    {
        SqlServer,
        Sqlite
    }
}
